import React from 'react';
import Popup from './components/Popup';

function App() {
  return (
    <div style={{ padding: '10px', width: '300px', height: '460px' }}>
      <Popup />
    </div>
  );
}

export default App;
