// background.js
console.log('Background script running');
